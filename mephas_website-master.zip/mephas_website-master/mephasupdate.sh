#!/bin/sh

mephas_web="/srv/shiny-server/mephas_web/"
mephas_website="/srv/shiny-server/mephas_website/"
cd $mephas_website
git pull
cd $mephas_web
git pull
