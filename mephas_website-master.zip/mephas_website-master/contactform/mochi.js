var num = 1 //questionNumber
var Q = num.toString();
var title = document.getElementById('momomochi');
var pic = document.getElementById('m');
var src = document.getElementById('pic');
var resetbu = document.getElementsByClassName('mochi-button');
var qtext = document.getElementsByClassName('mochi-title'); //配列！！！！！「「「
var a = document.getElementById('mochimochi'); //choice a
var b = document.getElementById('mochinomochi'); //choice b
var c = document.getElementById('momo'); //choice c
var condition = false;

var Questiontext = {
    "1": "What method are you looking for?",
    "A2": "Do you want to check a continuous or discrete probability?",
    "AA3": "Continuous Probability Distribution",
    "BA3": "Discrete Probability Distribution",

    "B2": "What is the underlying distribution of you data?",
    "AB3": "Compare the means",
    "BAB4": "Are the 2 groups extracted from >2 groups?",
    "ABAB5": "Are the 2 groups independent?",
    "CAB4": "ANOVA",

    "AAB4": "One-sample T test",
    "AABAB6": "Two-sample T test",
    "BABAB6": "Two paired sample T test",

    "BBAB5": "Multiple comparison post-hot test (Pairwise 1/2)",

    "ACAB5": "One-way ANOVA",
    "BCAB5": "Two-way ANOVA",
    "BB3": "How do you format your data",
    "ABB4": "How many samples do you want to test?", //"AABB5":"Do you have large sample size to make normal approximation valid?",
    "CABB5": "Are you interested in the trend of proportions?",

    "BBB4": "How do you format your contingency table?",
    "ABBB5": "Do you want to control confounding variable?",
    "AABBB6": "Is there any special point for your data?", //"BAABBB7":"All expected value in the cell >= 5 ?",
    "BBBB5": "Do you want to control for confounding variable?",

    "AABB5": "Chi-square test for one sample proportion",
    "BABB5": "Chi-square test for two independent sample proportions",
    "ACABB6": "Chi-square test for > two independent sample proportions",
    "BCABB6": "Chi-square trend test for > two independent sample proportions",

    "AAABBB7": "Chi-square test (2x2 table)",
    "BAABBB7": "Fisher exact test (2x2 table, exact)",
    "CAABBB7": "McNemar test (2x2 table, paired)",
    "BABBB6": "Mantel-Haenszel test (2x2xk table)",
    "ABBBB6": "Chi-square test (2xC, RxC table)",
    "BBBBB6": "Cochran-Mantel-Haenszel test(RxCxK table)",
    "CBBB5": "Cohen Kappa statistic (2xK, KxK table)",

    "CB3": "",
    "ACB4": "Non-parametric test",
    "BACB5": "Are the 2 groups extracted from >2 groups?",
    "ABACB6": "Are the 2 groups independent?",

    "C2": "How many rows (samples) and columns (variables) in your dataset",
    "AC3": "What kind of dependent variable (outcome / responders) in your dataset",
    "CAC4": "Do the dependent variable involve time and censoring",
    "BC3": "#samples <= #variables, #row <= #columns (n<=p issues)",
    "ABC4": "Consider the relation between independent and dependent variables?",

    "AACB5": "Wilcoxon signed-rank test for 1 sample",
    "AABACB7": "Wilcoxon rank-sum test / Mann-Whitney U test",
    "BABACB7": "Wilcoxon signed-rank test for paired sample",
    "CACB5": "Kruskal-Wallis test",

    //"ACAB5":"One-way ANOVA",
    //"BCAB5":"Two-way ANOVA",
    "BBACB6": "Multiple comparison post-hoc test after Kruskal-Wallis test (Pairwise3)",
    "AAC4": "The distribution of the dependent variable",
    "AAAC5": "Linear regression",
    "BAAC5": "Logistic regression",
    "CAAC5": "Which survival model is suitable",

    "BCB4": "Log-rank test or pairwse log-rank test for >2 survival curves",
    "ACAAC6": "Kaplan-Meier estimator",
    "CCAAC6": "Accelerate failure time (AFT) models",
    "BCAAC6": "Cox regression",

    "ABAC5": "Principal component analysis (PCA)",
    "BBAC5": "Exploratory factor analysis (EFA)",

    "AABC5": "Principal component regression (PCR)",
    "BABC5": "Partial least squares regression (PLSR)",
    "BBC4": "Sparse partial least squares regression (SPLSR)",

    "AAABAB7": "",
    "BAABAB7": "",
    //"BBAB5":"",

    "AAABB6": "",
    "BAABB6": "",
    //"BABB5":"",
    //"ACABB6":"",
    //"BCABB6":"",

    "ABAABBB7": "",
    "BBAABBB8": "",
    //"AACB5":"",
    "CBCB5": "",

    "AABC5": "",
    "BABC5": ""
}
var QustionsA = {
    "A1": "Probability distribution <h4>(e.g., to view the distribution shape, to compare data with a certain distribution, ...)",
    "AA2": "Continuous Probability Distribution<h4>(e.g., normal, exponential, gamma, beta, T, chi-squared, F distributions)",

    "AB2": "My data are real-valued and have underlying normal distribution<h4>(e.g., height, SBP, weight, ...)",
    "AAB3": "See if the only mean (from 1 sample group) is different from the specified mean",
    "ABAB4": "No, only 2 means (from 2 sample groups)",
    "AABAB5": "Yes, the 2 sample groups are independent",

    "ACAB4": "One-way ANOVA, because I only consider the effect from 1 factor variable",

    "ABB3": "Compare proportions or rates (shown in percentages)",
    "AABB4": "See if the only binomial proportion (from 1 sample) is different from a specified proportion",
    "ACABB5": "No, I want to see if the proportions are different",
    "ABBB4": "2x2 table <h4>(Usually used in case-control study test the association between two factors with two categories)",
    "AABBB5": "No, I do not consider the confounding variables",
    "ABBBB5": "No, I do not consider the confounding variables",
    "AAABBB6": "All the data in 2x2 table are independent",

    "ACB3": "Compare medians",
    "AACB4": "See if the only median (from 1 sample group) is different from the specified median",
    "ABACB5": "Yes, only 2 medians (from 2 sample groups)",
    "AABACB6": "Yes, the 2 sample groups are independent",

    "AC2": "Sample size > number of variables <h4>(number of rows > number of columns, n>p)",
    "AAC3": "Consider the dependent variable",
    "AAAC4": "The dependent variable is real-valued and continuous",
    "ACAAC5": "Non-parametric model: Kaplan-Meier estimator",
    "ABAC4": "Create important components (from the independent variables): principal component analysis (PCA)",
    "ABC3": "Generate components without section for modeling",
    //"AABC4":"Yes",
    "AABC4": "No, I do not consider the relation: principal components regression (PCR)",
    // "AAA3":"","ABA3":"",
    // "AAAB4":"","AAAABAB7":"","ABAABAB7":"","ABBAB5":"","AACAB5":"","ABCAB5":"","AAABAB6":"","ABABAB6":"","AAABB5":"","ACAABBB7":"",
    //   "AAAABB6":"","ABAABB6":"","ABABB5":"","AACABB6":"","ABCABB6":"","ABAABBB7":"","ACACB5":"",
    //   "AAAABBB7":"","AABAABBB7":"","ABBAABBB8":"","ABABBB6":"","AABBBB6":"","ABBBBB6":"","ACBBB5":"",
    // "AAACB5":"","AAABACB7":"","ABABACB7":"","ABBACB6":"","ACBCB5":"" ,"ABCB4":"",
    // "AACAC5":"","ABCAC5":"","ACCAC5":"","AAAAC5":"","ABAAC5":"",
    // "AAABC5":"","ABABC5":"","ABBC4":""//34
}
var QustionsB = {
    "B1": "Hypothesis testing method <h4>(e.g., to know the statistics, P value, estimate, 95% confidence interval,...)",
    "BA2": "Discrete Probability Distribution <h4>(e.g., Binomial, Poisson distributions)",
    "BAB3": "See if 2 means (from 2 groups) are different",
    "BBAB4": "Yes, I want to compare pairwise means (2 means from subset groups)",
    "BABAB5": "No, the 2 sample groups are matched or paired",

    "BCAB4": "Two-way ANOVA, because I consider the effect from 2 factor variables",

    "BB2": "My data are counts under categories or have underlying binomial distribution <h4>(e.g., number of success (number of yes or no), number of happenings, proportions, rates, percentages, ...)",
    "BABB4": "See if 2 binomial proportions (from 2 samples) are different.",
    "BAABB5": "No",
    "BCABB5": "Yes, I want to test the trend in the proportions",

    "BBB3": "Compare the number of counts arranged in a RxC table",
    "BABBB5": "Yes, I want to see the test result after controlling the confounding variable",
    "BAABBB6": "Data in the 2x2 table are independent, but there are very small counts (expected counts < 5) in some cells",

    //"BBABBB6":"No",
    "BBBB4": "RxC table <h4>(Usually to test the association between two factors with >2 categories)",
    "BBBBB5": "Yes, I want to see the test result after controlling confounding variable",

    "BCB3": "Compare survival probability curves",
    "BACB4": "See if 2 medians (from 2 sample groups) are different.",
    "BBACB5": "No, I want to compare pairwise medians (2 medians from subset groups)",
    "BABACB6": "No, the 2 sample groups are matched or paired",
    "BAC3": "Only consider the independent variable",
    "BBAC4": "Explore the factors (behind the independent variables): exploratory factor analysis (EFA)",
    "BAAC4": "The dependent variable is binary <h4>(e.g., 1/0, yes/no, true/false, success/failure,...)",
    "BCAAC5": "Semi-parametric model: Cox regression",
    "BC2": "Sample size <= number of variables <h4>(number of rows <= number of columns, n<=p issue)",
    //"BABC4":"No",
    "BABC4": "Yes, I consider the relation and the dependent variables may be multivariate: partial least squares regression (PLSR)",
    "BBC3": "Select variables and then generate components for modeling",
    //   "BAA3":"","BBA3":"",
    //   "BAAB4":"","BAAABAB7":"","BBAABAB7":"","BBBAB5":"","BACAB5":"","BBCAB5":"","BAABAB6":"","BBABAB6":"","BAABB5":"","BCAABBB7":"",
    //   "BAAABB6":"","BBAABB6":"","BBABB5":"","BACABB6":"","BBCABB6":"","BBAABBB7":"","BCACB5":"",
    //   "BAAABBB7":"","BABAABBB7":"","BBBAABBB8":"","BBABBB6":"","BABBBB6":"","BBBBBB6":"","BCBBB5":"",
    //   "BAACB5":"","BAABACB7":"","BBABACB7":"","BBBACB6":"","BCBCB5":"" ,"BBCB4":"",
    //   "BACAC5":"","BBCAC5":"","BCCAC5":"","BAAAC5":"","BBAAC5":"",
    //   "BAABC5":"","BBABC5":"","BBBC4":""
}
var QustionsC = {

    "C1": "Regression or modeling <h4>(e.g., to find the association between dependent and independent variables, to build a prediction model, ...)",
    "CAB3": "See if >2 means (from >2 sample groups) are different",
    "CABB4": "See if >2 binomial proportions (from >2 samples groups) are different",
    "CBBB4": "KxK or 2xK table <h4>(Usually to test the reproducibility of measurements)",

    "CAABBB6": "Data in 2x2 table are matched or paired.",

    "CB2": "My data are not underlying normal distributed nor binomial distributed<h4>(e.g., ordinal scale score, rankings, real-valued data in small sample size, survival times...)",
    "CACB4": "See if medians from >2 groups are different",

    "CAAC4": "The dependent variable is censored survival time",
    "CCAAC5": "Parametric model: accelerate failure time (AFT) models",
    // "CA2":"",
    // "CBAB4":"","CABAB5":"","CCAB4":"",
    // "CBB3":"","CAABB5":"","CCABB5":"",
    // "CABBB5":"","CBBBB5":"",
    // "CCB3":"","CBACB5":"","CABACB6":"",
    // "CC2":"",
    // "CBC3":"","CABC4":"",
    // "CAA3":"","CBA3":"",
    // "CAAB4":"","CAAABAB7":"","CBAABAB7":"","CBBAB5":"","CACAB5":"","CBCAB5":"","CAABAB6":"","CBABAB6":"","CAABB5":"","CCAABBB7":"",
    // "CAAABB6":"","CBAABB6":"","CBABB5":"","CACABB6":"","CBCABB6":"","CBAABBB7":"","CCACB5":"",
    // "CAAABBB7":"","CABAABBB7":"","CBBAABBB8":"","CBABBB6":"","CABBBB6":"","CBBBBB6":"","CCBBB5":"",
    // "CAACB5":"","CAABACB7":"","CBABACB7":"","CBBACB6":"","CCBCB5":"" ,"CBCB4":"",
    // "CBAC4":"","CACAC5":"","CBCAC5":"","CCCAC5":"","CAAAC5":"","CBAAC5":"",
    // "CAABC5":"","CBABC5":"","CBBC4":"","CAC3":""
}
var End = {
    "AA3": { "href": "../mephas_web/1_1MFScondist/", "img": "image/portfolio/s1.PNG" },
    "BA3": { "href": "../mephas_web/1_2MFSdisdist/", "img": "image/portfolio/s2.PNG" },
    "AAB4": { "href": "../mephas_web/2MFSttest/", "img": "image/portfolio/s3.PNG" },
    "AABAB6": { "href": "../mephas_web/2MFSttest/", "img": "image/portfolio/s10.PNG" },
    "BABAB6": { "href": "../mephas_web/2MFSttest/", "img": "image/portfolio/s11.PNG" },
    "AABB5": { "href": "../mephas_web/4MFSproptest/", "img": "image/portfolio/s5.PNG" },
    "BABB5": { "href": "../mephas_web/4MFSproptest/", "img": "image/portfolio/s14.PNG" },
    "ACABB6": { "href": "../mephas_web/4MFSproptest/", "img": "image/portfolio/s15.PNG" },
    "BCABB6": { "href": "../mephas_web/4MFSproptest/", "img": "image/portfolio/s16.PNG" },
    "AAABBB7": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s6.PNG" },
    "BAABBB7": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s17.PNG" },
    "CAABBB7": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s18.PNG" },
    "BABBB6": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s21.PNG" },
    "ABBBB6": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s19.PNG" },
    "CBBB5": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s20.PNG" },
    "BBBBB6": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s22.PNG" },
    "BBAB5": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s23.PNG" },
    "BBACB6": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s26.PNG" },
    "AACB5": { "href": "../mephas_web/3MFSnptest/", "img": "image/portfolio/s4.PNG" },
    "AABACB7": { "href": "../mephas_web/3MFSnptest/", "img": "image/portfolio/s12.PNG" },
    "BABACB7": { "href": "../mephas_web/3MFSnptest/", "img": "image/portfolio/s13.PNG" },
    "CACB5": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s25.PNG" },
    "ACAB5": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s7.PNG" },
    "BCAB5": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s24.PNG" },
    "AAAC5": { "href": "../mephas_web/7_1MFSlr/", "img": "image/portfolio/s27.PNG" },
    "BAAC5": { "href": "../mephas_web/7_2MFSlogit/", "img": "image/portfolio/s8.PNG" },
    "BCB4": { "href": "../mephas_web/7_3MFSsurv/", "img": "image/portfolio/s28.PNG" },
    "ACAAC6": { "href": "../mephas_web/7_3MFSsurv/", "img": "image/portfolio/s28.PNG" },
    "BCAAC6": { "href": "../mephas_web/7_3MFSsurv/", "img": "image/portfolio/s29.PNG" },
    "CCAAC6": { "href": "../mephas_web/7_3MFSsurv/", "img": "image/portfolio/s30.PNG" },
    "ABAC5": { "href": "../mephas_web/8_1MFSpca/", "img": "image/portfolio/s31.PNG" },
    "BBAC5": { "href": "../mephas_web/8_1MFSpca/", "img": "image/portfolio/s32.PNG" },
    "AABC5": { "href": "../mephas_web/8_2MFSpls/", "img": "image/portfolio/s33.PNG" },
    "BABC5": { "href": "../mephas_web/8_2MFSpls/", "img": "image/portfolio/s34.PNG" },
    "BBC4": { "href": "../mephas_web/8_2MFSpls/", "img": "image/portfolio/s35.PNG" }
    //"AAABAB7":{"href":"","img":""},"BAABAB7":{"href":"","img":""},"ACAB5":{"href":"","img":""},"BCAB5":{"href":"","img":""},
    //"AAABB6":{"href":"","img":""},"BAABB6":{"href":"","img":""},"BABB5":{"href":"","img":""},"ACABB6":{"href":"","img":""},"BCABB6":{"href":"","img":""},
    //"AAABBB7":{"href":"","img":""},"ABAABBB7":{"href":"","img":""},"BBAABBB8":{"href":"","img":""},"BABBB6":{"href":"","img":""},"ABBBB6":{"href":"","img":""},"CBBB5":{"href":"","img":""},
    //,"AABACB7":{"href":"","img":""},"BABACB7":{"href":"","img":""},"BBACB6":{"href":"","img":""},"CBCB5":{"href":"","img":""},"BCB4":{"href":"","img":""},
    //"AAC4":{"href":"","img":""},"BAC4":{"href":"","img":""},"ACAC5":{"href":"","img":""},"BCAC5":{"href":"","img":""},"CCAC5":{"href":"","img":""},
    //"AABC5":{"href":"","img":""},"BABC5":{"href":"","img":""},"BBC4":{"href":"","img":""}
}; //ゴール
var DirectryAhref = {
    /*"AAA3":"../mephas_web/1_1MFScondist/","AAAB4":"../mephas_web/2MFSttest/","AABAB5":"","AACAB5":"../mephas_web/6MFSanova/"*/
}
var DirectryBhref = {
    /* "BBA3":"../mephas_web/1_2MFSdisdist/","BAB3":"","BABAB5":"","BBAB4":"","ABCAB5":"../mephas_web/6MFSanova/"*/
}

function Reload() {
    qtext[1].innerHTML = Questiontext[Q];
    if (QustionsC['C' + Q] == "" || QustionsC['C' + Q] == null) {
        c.style.display = "none";
    } else {
        c.style.display = "block";
    }
    if (QustionsA['A' + Q] == "" || QustionsA['A' + Q] == null) {
        a.style.display = "none";
    } else {
        a.style.display = "block";
    }
    if (QustionsB['B' + Q] == "" || QustionsB['B' + Q] == null) {
        b.style.display = "none";
    } else {
        b.style.display = "block";
    }
    if (DirectryAhref['A' + Q]) { a.setAttribute("href", DirectryAhref['A' + Q]); } else { a.removeAttribute('href'); }
    if (DirectryBhref['B' + Q]) { b.setAttribute("href", DirectryBhref['B' + Q]); } else { b.removeAttribute('href'); }
    if (End[Q]) {
        a.style.display = "none";
        b.style.display = "none";
        c.style.display = "none";
        GoToEnd();
        return;
    } else {
        pic.style.display = "none";
    }
    a.innerHTML = QustionsA['A' + Q];
    b.innerHTML = QustionsB['B' + Q];
    c.innerHTML = QustionsC['C' + Q];
    // console.log(resetbu.getAttribute('href'));
}

function Restart() {
    num = 1;
    Q = num.toString();
    Reload();
}

function Back() {
    back();
    Reload();
}

function GoToEnd() {
    pic.style.display = "block";
    pic.setAttribute("href", End[Q]["href"]);
    src.setAttribute("src", End[Q]["img"]);
}

function next(mochi) {
    num++;
    Q = mochi + this.Q.substring(0, (this.Q.length) - 1) + num;
}

function back() {
    num--;
    Q = this.Q.substring(1, this.Q.length - 1) + num;
}

Reload();
// qtext[0].setAttribute("href","index_old.html");
// console.log(qtext[0].getAttribute('href'));
resetbu[0].onclick = function() {
    if (num == 1) { return }
    Back()
};
resetbu[1].onclick = function() {
    Restart()
};
$("#mochimochi").click(function() {
    next('A');
    Reload();
});
$("#mochinomochi").click(function() {
    next('B');
    Reload();
});
$("#momo").click(function() {
    next('C');
    Reload();
});