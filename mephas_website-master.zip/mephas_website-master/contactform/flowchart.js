var num = 1; //質問の順番
var qua = 6; //質問数
var branch = 'a'; //質問の分岐の種類
var speed = 300; //スライドの速度
var nextQ = num.toString(); //表示させるdiv（ID）の指定
var allclear = false; //trueなら最後の質問へ
const answer1 = 'qyyyy5';
const yes = 'y';
const no = 'n';
//質問のカウントアップ
function nq() {
    num++;
    nextQ = yes + nextQ.substring(0, (nextQ.length) - 1) + num;
}

//次の画面へ移動
function slide() {
    $('#' + nextQ).animate({ marginLeft: -650 }, speed);
    nq();
    $('#' + nextQ).animate({ marginLeft: 0 }, speed);
}

function MoveToNext(answer) {
    nextQMove(-650);
    go(answer);
    nextQMove(0);
}

function MoveToBuck() {
    nextQMove(650);
    back();
    nextQMove(0);
}

function go(answer) {
    num++;
    nextQ = answer + nextQ.substring(0, (nextQ.length) - 1) + num;
    console.log(nextQ);
}

function back() {
    num--;
    nextQ = nextQ.substring(1, nextQ.length - 1) + num;
}

function MoveToAnswer(answer) {
    $('#check ul').animate({ opacity: 0 }, speed);
    slideinvisible();
    Answer(answer);
}

function Answer(answer) {
    $('#' + answer).animate({ marginLeft: 0 }, speed);
}

function nextQMove(x) {
    $('#' + nextQ).animate({ marginLeft: x }, speed);
}
//解決しましたか？画面の表示
function kaiketsu() {
    $('#kaiketsu dt span').text('質問' + num);
    allclear = true;
    $('#kaiketsu').animate({ marginLeft: 0 }, speed);
}

//最後の画面
function saigo(n) {
    $('#check ul').animate({ opacity: 0 }, speed);
    $('#kaiketsu').animate({ marginLeft: -650 }, speed);
    $('#' + n).animate({ marginLeft: 0 }, speed);

}

$("#back").click(function() {
    if (nextQ == '1' || allclear == true) {
        return;
    }
    MoveToBuck();
});
//『はい』を選択した際の動き
$("#yes").click(function() {
    if (allclear == true) { return; }
    MoveToNext(yes);
});

//『いいえ』を選択した際の動き
$("#no").click(function() {
    if (allclear == true) { return; }
    MoveToNext(no);
});