var num = 1 //questionNumber
var Q = num.toString();
var title = document.getElementById('momomochi');
var pic = document.getElementById('m');
var src = document.getElementById('pic');
var resetbu = document.getElementsByClassName('mochi-button');
var qtext = document.getElementsByClassName('mochi-title'); //配列！！！！！「「「
var a = document.getElementById('mochimochi'); //choice a
var b = document.getElementById('mochinomochi'); //choice b
var c = document.getElementById('momo'); //choice c
var condition = false;

var Questiontext = {
    "1": "どのような手法をお探しですか?",
    "A2": "連続確率と離散確率のどちらかの確認ですか?",
    "AA3": "連続確率分布",
    "BA3": "離散確率分布",

    "B2": "あなたのデータのどのような分布に従いますか?",
    "AB3": "平均を比較する",
    "BAB4": "2つのグループは3つ以上ののグループから抽出されていますか？",
    "ABAB5": "2つのグループは独立していますか？",
    "CAB4": "ANOVA",

    "AAB4": "1標本T検定",
    "AABAB6": "2標本T検定",
    "BABAB6": "2つの対応のあるサンプルのT検定",

    "BBAB5": "多重比較ポストホットテスト（ペアワイズ1/2）",

    "ACAB5": "一元配置分散分析(One-way ANOVA)",
    "BCAB5": "二元配置分散分析(Two-way ANOVA)",
    "BB3": "データをどのようにフォーマットしますか?",
    "ABB4": "テストするサンプルの数はどれぐらいですか?", //"AABB5":"Do you have large sample size to make normal approximation valid?",
    "CABB5": "比例のトレンドに興味がありますか?",

    "BBB4": "分割表をどのようにフォーマットしますか?",
    "ABBB5": "交絡変数を制御しますか?",
    "AABBB6": "データに特別なポイントはありますか?", //"BAABBB7":"All expected value in the cell >= 5 ?",
    "BBBB5": "交絡変数を制御しますか?",

    "AABB5": "1つのサンプル比率のカイ2乗検定",
    "BABB5": "2つの独立したサンプル比率のカイ2乗検定",
    "ACABB6": "3つ以上の独立したサンプル比率のカイ2乗検定",
    "BCABB6": "3つ以上の独立したサンプル比率のカイ2乗傾向検定",

    "AAABBB7": "カイ二乗検定(2x2 table)",
    "BAABBB7": "フィッシャーの正確確率検定 (2x2 table, exact)",
    "CAABBB7": "マクネマー検定 (2x2 table, paired)",
    "BABBB6": "マンテル-ヘンツェル検定 (2x2xk table)",
    "ABBBB6": "カイ二乗検定 (2xC, RxC table)",
    "BBBBB6": "コクラン-マンテル-ヘンツェル検定 test(RxCxK table)",
    "CBBB5": "カッパ係数 (2xK, KxK table)",

    "CB3": "",
    "ACB4": "ノンパラメトリック検定",
    "BACB5": "2つのグループは3つ以上ののグループから抽出されていますか?",
    "ABACB6": "2つのグループは独立していますか?",

    "C2": "データセット内の行（サンプル）と列（変数）の数どれぐらいありますか？",
    "AC3": "データセット内の従属変数（アウトカム/レスポンダー）の種類は何ですか？",
    "CAC4": "従属変数には時間と打ち切りが含まれますか",
    "BC3": "#samples <=＃variables、＃row <= #columns（n <= pの問題）",
    "ABC4": "独立変数と従属変数の関係を検討していますか?",

    "AACB5": "1サンプルのウィルコクソン符号順位検定",
    "AABACB7": "ウィルコクソン順位和検定/マンホイットニーU検定",
    "BABACB7": "対応サンプルのウィルコクソン符号順位検定",
    "CACB5": "クラスカル・ウォリス検定",

    //"ACAB5":"One-way ANOVA",
    //"BCAB5":"Two-way ANOVA",
    "BBACB6": "クラスカル・ウォリス検定後の多重比較事後検定（Pairwise3）",
    "AAC4": "従属変数の分布",
    "AAAC5": "線形回帰",
    "BAAC5": "ロジスティック回帰",
    "CAAC5": "どの生存モデルが適していますか",

    "BCB4": "生存曲線のログランク検定または3つ以上の対応ログランク検定",
    "ACAAC6": "カプランマイヤー推定量",
    "CCAAC6": "故障時間の加速（AFT）モデル",
    "BCAAC6": "Cox回帰",

    "ABAC5": "主成分分析（PCA）",
    "BBAC5": "探索的因子分析（EFA）",

    "AABC5": "主成分回帰（PCR）",
    "BABC5": "部分最小二乗回帰（PLSR）",
    "BBC4": "スパース部分最小二乗回帰（SPLSR）",

    "AAABAB7": "",
    "BAABAB7": "",
    //"BBAB5":"",

    "AAABB6": "",
    "BAABB6": "",
    //"BABB5":"",
    //"ACABB6":"",
    //"BCABB6":"",

    "ABAABBB7": "",
    "BBAABBB8": "",
    //"AACB5":"",
    "CBCB5": "",

    "AABC5": "",
    "BABC5": ""
}
var QustionsA = {
    "A1": "確率分布<h4>（例えば、分布の形状を表示する、データを特定の分布と比較する, ...)",
    "AA2": "連続確率分布<h4>（例えば、正規、指数、ガンマ、ベータ、T、カイ2乗、F分布）",

    "AB2": "私のデータは実数値であり、正規分布に従います<h4>（例えば、高さ、SBP、体重など）",
    "AAB3": "（1つのサンプルグループからの）一つの平均値が指定された平均と異なるかどうかを確認します",
    "ABAB4": "いいえ、（2つのサンプルグループからの）2つの平均があります",
    "AABAB5": "はい、2つのサンプルグループは独立しています",

    "ACAB4": "一元配置分散分析、1因子変数からの効果のみを考慮するため",

    "ABB3": "（パーセンテージで表示する）比率またはレートを比較します",
    "AABB4": "（1つのサンプルからの）一つの二項比率が指定された比率と異なるかどうかを確認します",
    "ACABB5": "いいえ、複数の比率が違うか見たいです",
    "ABBB4": "2x2テーブル<h4>（通常、ケースコントロール研究で使用され、2つのカテゴリーの2つの要因間の関連性をテストします）",
    "AABBB5": "いいえ、交絡変数は考慮していません",
    "ABBBB5": "いいえ、交絡変数は考慮していません",
    "AAABBB6": "2x2テーブルのすべてのデータは独立しています",

    "ACB3": "中央値を比較する",
    "AACB4": "（1つのサンプルグループからの）一つの中央値が指定された中央値と異なるかどうかを確認します",
    "ABACB5": "はい、（2つのサンプルグループからの）2つの中央値があります",
    "AABACB6": "はい、2つのサンプルグループは独立しています",

    "AC2": "サンプルサイズ>変数の数<h4>（行の数>列の数、n> p）",
    "AAC3": "従属変数を検討します",
    "AAAC4": "従属変数は実数値で連続です",
    "ACAAC5": "ノンパラメトリックモデル：カプランマイヤー推定量",
    "ABAC4": "（独立変数から）重要なコンポーネントを作成する：主成分分析（PCA）",
    "ABC3": "モデリング用のセクションなしでコンポーネントを生成する",
    //"AABC4":"Yes",
    "AABC4": "いいえ、関係は考慮していません：主成分回帰（PCR）",
    // "AAA3":"","ABA3":"",
    // "AAAB4":"","AAAABAB7":"","ABAABAB7":"","ABBAB5":"","AACAB5":"","ABCAB5":"","AAABAB6":"","ABABAB6":"","AAABB5":"","ACAABBB7":"",
    //   "AAAABB6":"","ABAABB6":"","ABABB5":"","AACABB6":"","ABCABB6":"","ABAABBB7":"","ACACB5":"",
    //   "AAAABBB7":"","AABAABBB7":"","ABBAABBB8":"","ABABBB6":"","AABBBB6":"","ABBBBB6":"","ACBBB5":"",
    // "AAACB5":"","AAABACB7":"","ABABACB7":"","ABBACB6":"","ACBCB5":"" ,"ABCB4":"",
    // "AACAC5":"","ABCAC5":"","ACCAC5":"","AAAAC5":"","ABAAC5":"",
    // "AAABC5":"","ABABC5":"","ABBC4":""//34
}
var QustionsB = {
    "B1": "仮説検定法<h4>（例えば、統計、P値、推定値、95％信頼区間などを知るため）",
    "BA2": "離散確率分布<h4>（例えば、二項分布、ポアソン分布）",
    "BAB3": "（2つのグループからの）2つの平均が異なるかどうかを確認します",
    "BBAB4": "はい、ペアワイズ平均を比較したい（サブセットグループからの2つの平均）",
    "BABAB5": "いいえ、2つのサンプルグループはマッチングされていますまたはペアになっています",

    "BCAB4": "二元配置分散分析、2要因変数からの影響を考慮するため",

    "BB2": "私のデータは、カテゴリの下でのカウントまたは、二項分布に従います<h4>（たとえば、成功の数（はいまたはいいえの数）、発生の数、比率、率、パーセンテージなど）",
    "BABB4": "（2つのサンプルからの）2つの二項比率が異なるかどうかを確認します",
    "BAABB5": "いいえ",
    "BCABB5": "はい、比率の傾向をテストしたいです",

    "BBB3": "RxCテーブルに配置されたカウント数を比較します",
    "BABBB5": "はい、交絡変数を制御した後のテスト結果を見たいです",
    "BAABBB6": "2x2テーブルのデータは独立していますが、一部のセルには非常に少ないカウント（カウント<5）があります",

    //"BBABBB6":"No",
    "BBBB4": "RxCテーブル<h4>（通常、3つ以上のカテゴリを持つ2つの要因間の関連をテストするため）",
    "BBBBB5": "はい、交絡変数を制御した後のテスト結果を見たいです",

    "BCB3": "生存確率曲線を比較します",
    "BACB4": "（2つのサンプルグループからの）2つの中央値が異なるかどうかを確認します",
    "BBACB5": "（2つのサンプルグループからの）2つの中央値が異なるかどうかを確認します",
    "BABACB6": "いいえ、2つのサンプルグループはマッチングされていますまたはペアになっています",
    "BAC3": "独立変数のみを考慮します",
    "BBAC4": "（独立変数の背後にある）因子を探索する：探索的因子分析（EFA）",
    "BAAC4": "従属変数はバイナリ<h4>です（例えば、1/0、yes / no、true / false、success / failed、...）",
    "BCAAC5": "セミパラメトリックモデル：Cox回帰",
    "BC2": "サンプルサイズ<=変数の数<h4>（行の数<=列の数、n <= pの問題）",
    //"BABC4":"No",
    "BABC4": "はい、関係を考慮する。従属変数は多変量である可能性がある：部分最小二乗回帰（PLSR）",
    "BBC3": "変数を選択してから、モデリング用のコンポーネントを生成します",
    //   "BAA3":"","BBA3":"",
    //   "BAAB4":"","BAAABAB7":"","BBAABAB7":"","BBBAB5":"","BACAB5":"","BBCAB5":"","BAABAB6":"","BBABAB6":"","BAABB5":"","BCAABBB7":"",
    //   "BAAABB6":"","BBAABB6":"","BBABB5":"","BACABB6":"","BBCABB6":"","BBAABBB7":"","BCACB5":"",
    //   "BAAABBB7":"","BABAABBB7":"","BBBAABBB8":"","BBABBB6":"","BABBBB6":"","BBBBBB6":"","BCBBB5":"",
    //   "BAACB5":"","BAABACB7":"","BBABACB7":"","BBBACB6":"","BCBCB5":"" ,"BBCB4":"",
    //   "BACAC5":"","BBCAC5":"","BCCAC5":"","BAAAC5":"","BBAAC5":"",
    //   "BAABC5":"","BBABC5":"","BBBC4":""
}
var QustionsC = {

    "C1": "回帰またはモデリング<h4>（例えば、従属変数と独立変数の間の関連付けを見つける、予測モデルを構築する、...）",
    "CAB3": "（３つ以上のサンプルグループからの）3つ以上の平均が異なるかどうかを確認します",
    "CABB4": "（３つ以上のサンプルグループからの）3つ以上の二項比例が異なるかどうかを確認します",
    "CBBB4": "KxKまたは2xKテーブル<h4>（通常、測定の再現性をテストするため）",

    "CAABBB6": "2x2テーブルのデータがマッチングされていますまたはペアになっています",

    "CB2": "私のデータは、正規分布にも二項分布にも従いません<h4>（例えば、順序尺度スコア、ランキング、小さなサンプルサイズの実数値データ、生存時間など）",
    "CACB4": "2つ以上のグループの中央値が異なるかどうかを確認します",

    "CAAC4": "従属変数は打ち切られた生存時間です",
    "CCAAC5": "パラメトリックモデル：故障時間加速（AFT）モデル",
    // "CA2":"",
    // "CBAB4":"","CABAB5":"","CCAB4":"",
    // "CBB3":"","CAABB5":"","CCABB5":"",
    // "CABBB5":"","CBBBB5":"",
    // "CCB3":"","CBACB5":"","CABACB6":"",
    // "CC2":"",
    // "CBC3":"","CABC4":"",
    // "CAA3":"","CBA3":"",
    // "CAAB4":"","CAAABAB7":"","CBAABAB7":"","CBBAB5":"","CACAB5":"","CBCAB5":"","CAABAB6":"","CBABAB6":"","CAABB5":"","CCAABBB7":"",
    // "CAAABB6":"","CBAABB6":"","CBABB5":"","CACABB6":"","CBCABB6":"","CBAABBB7":"","CCACB5":"",
    // "CAAABBB7":"","CABAABBB7":"","CBBAABBB8":"","CBABBB6":"","CABBBB6":"","CBBBBB6":"","CCBBB5":"",
    // "CAACB5":"","CAABACB7":"","CBABACB7":"","CBBACB6":"","CCBCB5":"" ,"CBCB4":"",
    // "CBAC4":"","CACAC5":"","CBCAC5":"","CCCAC5":"","CAAAC5":"","CBAAC5":"",
    // "CAABC5":"","CBABC5":"","CBBC4":"","CAC3":""
}
var End = {
    "AA3": { "href": "../mephas_web/1_1MFScondist/", "img": "image/portfolio/s1.PNG" },
    "BA3": { "href": "../mephas_web/1_2MFSdisdist/", "img": "image/portfolio/s2.PNG" },
    "AAB4": { "href": "../mephas_web/2MFSttest/", "img": "image/portfolio/s3.PNG" },
    "AABAB6": { "href": "../mephas_web/2MFSttest/", "img": "image/portfolio/s10.PNG" },
    "BABAB6": { "href": "../mephas_web/2MFSttest/", "img": "image/portfolio/s11.PNG" },
    "AABB5": { "href": "../mephas_web/4MFSproptest/", "img": "image/portfolio/s5.PNG" },
    "BABB5": { "href": "../mephas_web/4MFSproptest/", "img": "image/portfolio/s14.PNG" },
    "ACABB6": { "href": "../mephas_web/4MFSproptest/", "img": "image/portfolio/s15.PNG" },
    "BCABB6": { "href": "../mephas_web/4MFSproptest/", "img": "image/portfolio/s16.PNG" },
    "AAABBB7": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s6.PNG" },
    "BAABBB7": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s17.PNG" },
    "CAABBB7": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s18.PNG" },
    "BABBB6": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s21.PNG" },
    "ABBBB6": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s19.PNG" },
    "CBBB5": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s20.PNG" },
    "BBBBB6": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s22.PNG" },
    "BBAB5": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s23.PNG" },
    "BBACB6": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s26.PNG" },
    "AACB5": { "href": "../mephas_web/3MFSnptest/", "img": "image/portfolio/s4.PNG" },
    "AABACB7": { "href": "../mephas_web/3MFSnptest/", "img": "image/portfolio/s12.PNG" },
    "BABACB7": { "href": "../mephas_web/3MFSnptest/", "img": "image/portfolio/s13.PNG" },
    "CACB5": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s25.PNG" },
    "ACAB5": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s7.PNG" },
    "BCAB5": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s24.PNG" },
    "AAAC5": { "href": "../mephas_web/7_1MFSlr/", "img": "image/portfolio/s27.PNG" },
    "BAAC5": { "href": "../mephas_web/7_2MFSlogit/", "img": "image/portfolio/s8.PNG" },
    "BCB4": { "href": "../mephas_web/7_3MFSsurv/", "img": "image/portfolio/s28.PNG" },
    "ACAAC6": { "href": "../mephas_web/7_3MFSsurv/", "img": "image/portfolio/s28.PNG" },
    "BCAAC6": { "href": "../mephas_web/7_3MFSsurv/", "img": "image/portfolio/s29.PNG" },
    "CCAAC6": { "href": "../mephas_web/7_3MFSsurv/", "img": "image/portfolio/s30.PNG" },
    "ABAC5": { "href": "../mephas_web/8_1MFSpca/", "img": "image/portfolio/s31.PNG" },
    "BBAC5": { "href": "../mephas_web/8_1MFSpca/", "img": "image/portfolio/s32.PNG" },
    "AABC5": { "href": "../mephas_web/8_2MFSpls/", "img": "image/portfolio/s33.PNG" },
    "BABC5": { "href": "../mephas_web/8_2MFSpls/", "img": "image/portfolio/s34.PNG" },
    "BBC4": { "href": "../mephas_web/8_2MFSpls/", "img": "image/portfolio/s35.PNG" }
    //"AAABAB7":{"href":"","img":""},"BAABAB7":{"href":"","img":""},"ACAB5":{"href":"","img":""},"BCAB5":{"href":"","img":""},
    //"AAABB6":{"href":"","img":""},"BAABB6":{"href":"","img":""},"BABB5":{"href":"","img":""},"ACABB6":{"href":"","img":""},"BCABB6":{"href":"","img":""},
    //"AAABBB7":{"href":"","img":""},"ABAABBB7":{"href":"","img":""},"BBAABBB8":{"href":"","img":""},"BABBB6":{"href":"","img":""},"ABBBB6":{"href":"","img":""},"CBBB5":{"href":"","img":""},
    //,"AABACB7":{"href":"","img":""},"BABACB7":{"href":"","img":""},"BBACB6":{"href":"","img":""},"CBCB5":{"href":"","img":""},"BCB4":{"href":"","img":""},
    //"AAC4":{"href":"","img":""},"BAC4":{"href":"","img":""},"ACAC5":{"href":"","img":""},"BCAC5":{"href":"","img":""},"CCAC5":{"href":"","img":""},
    //"AABC5":{"href":"","img":""},"BABC5":{"href":"","img":""},"BBC4":{"href":"","img":""}
}; //ゴール
var DirectryAhref = {
    /*"AAA3":"../mephas_web/1_1MFScondist/","AAAB4":"../mephas_web/2MFSttest/","AABAB5":"","AACAB5":"../mephas_web/6MFSanova/"*/
}
var DirectryBhref = {
    /* "BBA3":"../mephas_web/1_2MFSdisdist/","BAB3":"","BABAB5":"","BBAB4":"","ABCAB5":"../mephas_web/6MFSanova/"*/
}

function Reload() {
    qtext[1].innerHTML = Questiontext[Q];
    if (QustionsC['C' + Q] == "" || QustionsC['C' + Q] == null) {
        c.style.display = "none";
    } else {
        c.style.display = "block";
    }
    if (QustionsA['A' + Q] == "" || QustionsA['A' + Q] == null) {
        a.style.display = "none";
    } else {
        a.style.display = "block";
    }
    if (QustionsB['B' + Q] == "" || QustionsB['B' + Q] == null) {
        b.style.display = "none";
    } else {
        b.style.display = "block";
    }
    if (DirectryAhref['A' + Q]) { a.setAttribute("href", DirectryAhref['A' + Q]); } else { a.removeAttribute('href'); }
    if (DirectryBhref['B' + Q]) { b.setAttribute("href", DirectryBhref['B' + Q]); } else { b.removeAttribute('href'); }
    if (End[Q]) {
        a.style.display = "none";
        b.style.display = "none";
        c.style.display = "none";
        GoToEnd();
        return;
    } else {
        pic.style.display = "none";
    }
    a.innerHTML = QustionsA['A' + Q];
    b.innerHTML = QustionsB['B' + Q];
    c.innerHTML = QustionsC['C' + Q];
    // console.log(resetbu.getAttribute('href'));
}

function Restart() {
    num = 1;
    Q = num.toString();
    Reload();
}

function Back() {
    back();
    Reload();
}

function GoToEnd() {
    pic.style.display = "block";
    pic.setAttribute("href", End[Q]["href"]);
    src.setAttribute("src", End[Q]["img"]);
}

function next(mochi) {
    num++;
    Q = mochi + this.Q.substring(0, (this.Q.length) - 1) + num;
}

function back() {
    num--;
    Q = this.Q.substring(1, this.Q.length - 1) + num;
}

Reload();
// qtext[0].setAttribute("href","index_old.html");
// console.log(qtext[0].getAttribute('href'));
resetbu[0].onclick = function() {
    if (num == 1) { return }
    Back()
};
resetbu[1].onclick = function() {
    Restart()
};
$("#mochimochi").click(function() {
    next('A');
    Reload();
});
$("#mochinomochi").click(function() {
    next('B');
    Reload();
});
$("#momo").click(function() {
    next('C');
    Reload();
});