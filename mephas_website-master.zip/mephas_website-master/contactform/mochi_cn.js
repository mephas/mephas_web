var num = 1 //questionNumber
var Q = num.toString();
var title = document.getElementById('momomochi');
var pic = document.getElementById('m');
var src = document.getElementById('pic');
var resetbu = document.getElementsByClassName('mochi-button');
var qtext = document.getElementsByClassName('mochi-title'); //配列！！！！！「「「
var a = document.getElementById('mochimochi'); //choice a
var b = document.getElementById('mochinomochi'); //choice b
var c = document.getElementById('momo'); //choice c
var condition = false;

var Questiontext = {
    "1": "您在寻找什么方法?",
    "A2": "您要查看连续概率还是离散概率?",
    "AA3": "连续概率",
    "BA3": "离散概率",

    "B2": "您的数据的服从什么分布?",
    "AB3": "平均值比较",
    "BAB4": "是否从> 2组中提取了2组？?",
    "ABAB5": "这两个组是否独立?",
    "CAB4": "ANOVA",

    "AAB4": "一样本T检验",
    "AABAB6": "两样本T检验",
    "BABAB6": "两对样本T检验",

    "BBAB5": "事后多重比较测试（成对1/2）",

    "ACAB5": "单向方差分析",
    "BCAB5": "两向方差分析",
    "BB3": "您的数据的格式？",
    "ABB4": "您要测试多少个样品?", //"AABB5":"Do you have large sample size to make normal approximation valid?",
    "CABB5": "您对比例趋势感兴趣吗?",

    "BBB4": "您的列联表的格式?",
    "ABBB5": "是否控制混杂变量?",
    "AABBB6": "您的数据有什么特别之处吗?", //"BAABBB7":"All expected value in the cell >= 5 ?",
    "BBBB5": "是否控制混杂变量?",

    "AABB5": "用于一个样本比例的卡方检验",
    "BABB5": "两个独立样本比例的卡方检验",
    "ACABB6": ">两个独立样本比例的卡方检验",
    "BCABB6": ">两个独立样本比例的卡方趋势检验",

    "AAABBB7": "卡方检验（2x2表格）",
    "BAABBB7": "Fisher精确检验（2x2表格，精确）",
    "CAABBB7": "McNemar检验（2x2表格，成对）",
    "BABBB6": "Mantel-Haenszel检验（2x2xk表）",
    "ABBBB6": "卡方检验（2xC，RxC表）",
    "BBBBB6": "Cochran-Mantel-Haenszel检验（RxCxK表）",
    "CBBB5": "Cohen Kappa统计量（2xK，KxK表）",

    "CB3": "",
    "ACB4": "非参数检验",
    "BACB5": "是否从> 2组中提取了2组？",
    "ABACB6": "这两个组是否独立？",

    "C2": "数据集中有多少行（样本）和列（变量）",
    "AC3": "您的数据集是什么样的因变量（结果/应答变量）",
    "CAC4": "因变量是否涉及时间和删失",
    "BC3": "#samples <= #variables, #row <= #columns (n<=p 问题)",
    "ABC4": "是否考虑自变量和因变量之间的关系?",

    "AACB5": "单样本的Wilcoxon 秩检验",
    "AABACB7": "Wilcoxon秩和检验/ Mann-Whitney U检验",
    "BABACB7": "配对样本的Wilcoxon符号秩检验",
    "CACB5": "Kruskal-Wallis检验",

    //"ACAB5":"One-way ANOVA",
    //"BCAB5":"Two-way ANOVA",
    "BBACB6": "Kruskal-Wallis检验后的多重比较事后检验（Pairwise3）",
    "AAC4": "因变量的分布",
    "AAAC5": "线性回归",
    "BAAC5": "逻辑回归",
    "CAAC5": "哪种生存模型更为合适",

    "BCB4": "对数秩检验或> 2条生存曲线的成对对数秩检验",
    "ACAAC6": "Kaplan-Meier估算",
    "CCAAC6": "加速故障时间（AFT）模型",
    "BCAAC6": "考克斯（Cox）回归",

    "ABAC5": "主成分分析（PCA）",
    "BBAC5": "探索性因素分析（EFA）",

    "AABC5": "主成分回归（PCR）",
    "BABC5": "偏最小二乘回归（PLSR）",
    "BBC4": "稀疏偏最小二乘回归（SPLSR）",

    "AAABAB7": "",
    "BAABAB7": "",
    //"BBAB5":"",

    "AAABB6": "",
    "BAABB6": "",
    //"BABB5":"",
    //"ACABB6":"",
    //"BCABB6":"",

    "ABAABBB7": "",
    "BBAABBB8": "",
    //"AACB5":"",
    "CBCB5": "",

    "AABC5": "",
    "BABC5": ""
}
var QustionsA = {
    "A1": "概率分布<h4>（例如，查看分布形状，比较具有特定分布的数据等）",
    "AA2": "连续概率分布<h4>（例如，正态，指数，伽马，β，T，卡方，F分布）",

    "AB2": "我的数据是实数值且基于正态分布<h4>（例如，身高，SBP，体重等）",
    "AAB3": "检验（一组样本中的）一个平均值是否与指定的平均值不同",
    "ABAB4": "不，有（来自2个样本组的）2个均值",
    "AABAB5": "是的，这两个样本组是独立的",

    "ACAB4": "单向方差分析，因为我仅考虑1个因子变量的影响",

    "ABB3": "比较（以百分比显示的）比例或比率",
    "AABB4": "检验（一组样本中的）一个二项比例是否与指定比例不同",
    "ACABB5": "不，我想看看多组比例是否不同",
    "ABBB4": "2x2表格<h4>（通常用于病例对照研究中，用于检验两个因素与两个类别之间的关联）",
    "AABBB5": "不，我不考虑混杂变量",
    "ABBBB5": "不，我不考虑混杂变量",
    "AAABBB6": "2x2表中的所有数据都是独立的",

    "ACB3": "比较中位数",
    "AACB4": "检验（一组样本中的）一个中位数是否与指定中位数不同",
    "ABACB5": "是的，只有（来自2个样本组的）2个中位数",
    "AABACB6": "是的，这两个样本组是独立的",

    "AC2": "样本大小>变量数<h4>(行数>列数，n> p)",
    "AAC3": "考虑因变量",
    "AAAC4": "因变量是实数值且连续",
    "ACAAC5": "非参数模型：Kaplan-Meier估计器",
    "ABAC4": "（通过自变量）创建重要成分：主成分分析（PCA）",
    "ABC3": "生成没有用于建模的部分的成分",
    //"AABC4":"Yes",
    "AABC4": "不，我不考虑这种关系：主成分回归（PCR）",
    // "AAA3":"","ABA3":"",
    // "AAAB4":"","AAAABAB7":"","ABAABAB7":"","ABBAB5":"","AACAB5":"","ABCAB5":"","AAABAB6":"","ABABAB6":"","AAABB5":"","ACAABBB7":"",
    //   "AAAABB6":"","ABAABB6":"","ABABB5":"","AACABB6":"","ABCABB6":"","ABAABBB7":"","ACACB5":"",
    //   "AAAABBB7":"","AABAABBB7":"","ABBAABBB8":"","ABABBB6":"","AABBBB6":"","ABBBBB6":"","ACBBB5":"",
    // "AAACB5":"","AAABACB7":"","ABABACB7":"","ABBACB6":"","ACBCB5":"" ,"ABCB4":"",
    // "AACAC5":"","ABCAC5":"","ACCAC5":"","AAAAC5":"","ABAAC5":"",
    // "AAABC5":"","ABABC5":"","ABBC4":""//34
}
var QustionsB = {
    "B1": "假设检验方法<h4>（例如，要了解统计信息，P值，估计值，95％置信区间等）",
    "BA2": "离散概率分布<h4>（例如，二项式，泊松分布）",
    "BAB3": "检验（来自2组的）2个均值是否不同",
    "BBAB4": "是的，我想比较成对均值（子集组中的2个均值）",
    "BABAB5": "否，这两个样本组是匹配或配对的",

    "BCAB4": "双向方差分析，因为我考虑了2个因子变量的影响",

    "BB2": "我的数据是类别下的计数或服从二项式分布<h4>（例如成功次数（是或否），发生次数，比例，比率，百分比等）",
    "BABB4": "检验（来自2组的）2个二项比例是否不同",
    "BAABB5": "不",
    "BCABB5": "是的，我想测试比例趋势",

    "BBB3": "比较RxC表中排列的计数",
    "BABBB5": "是的，我想在控制混杂变量后查看检验结果",
    "BAABBB6": "2x2表中的数据是独立的，但某些单元格中的计数非常小（预期计数<5）",

    //"BBABBB6":"No",
    "BBBB4": "RxC表<h4>（通常用于测试具有> 2个类别的两个因子之间的关联）",
    "BBBBB5": "是的，我想在控制混杂变量后查看检验结果",

    "BCB3": "比较生存概率曲线",
    "BACB4": "检验（来自2组的）2个中位数是否不同",
    "BBACB5": "不，我想比较成对的中位数（子集组的2个中位数）",
    "BABACB6": "不，这两个样本组是匹配或配对的",
    "BAC3": "只考虑自变量",
    "BBAC4": "探索（独立变量背后的）因素：探索性因素分析（EFA）",
    "BAAC4": "因变量是二项数值<h4>（例如，1/0，是/否，是/否，成功/失败等）",
    "BCAAC5": "半参数模型：Cox回归",
    "BC2": "样本大小<=变量数<h4>（行数<=列数，n <= p问题）",
    //"BABC4":"No",
    "BABC4": "是的，我考虑这种关系。因变量可以是多元的：偏最小二乘回归（PLSR）",
    "BBC3": "选择变量，然后生成用于建模的成分",
    //   "BAA3":"","BBA3":"",
    //   "BAAB4":"","BAAABAB7":"","BBAABAB7":"","BBBAB5":"","BACAB5":"","BBCAB5":"","BAABAB6":"","BBABAB6":"","BAABB5":"","BCAABBB7":"",
    //   "BAAABB6":"","BBAABB6":"","BBABB5":"","BACABB6":"","BBCABB6":"","BBAABBB7":"","BCACB5":"",
    //   "BAAABBB7":"","BABAABBB7":"","BBBAABBB8":"","BBABBB6":"","BABBBB6":"","BBBBBB6":"","BCBBB5":"",
    //   "BAACB5":"","BAABACB7":"","BBABACB7":"","BBBACB6":"","BCBCB5":"" ,"BBCB4":"",
    //   "BACAC5":"","BBCAC5":"","BCCAC5":"","BAAAC5":"","BBAAC5":"",
    //   "BAABC5":"","BBABC5":"","BBBC4":""
}
var QustionsC = {

    "C1": "回归或建模<h4>（例如，找到因变量和自变量之间的关联，以建立预测模型等）",
    "CAB3": "检验（来自> 2个样本组的）> 2平均值是否不同",
    "CABB4": "检验（来自> 2个样本组的）> 2二项比例是否不同",
    "CBBB4": "KxK或2xK表<h4>（通常用于测试测量值的可重复性）",

    "CAABBB6": "2x2表中的数据是匹配或成对的",

    "CB2": "我的数据既不服从正态分布也不服从二项式分布<h4>（例如，序数标度得分，排名，小样本量的实值数据，生存时间等）",
    "CACB4": "检验> 2组的中位数是否不同",

    "CAAC4": "因变量是删失的生存时间",
    "CCAAC5": "参数模型：加速故障时间（AFT）模型",
    // "CA2":"",
    // "CBAB4":"","CABAB5":"","CCAB4":"",
    // "CBB3":"","CAABB5":"","CCABB5":"",
    // "CABBB5":"","CBBBB5":"",
    // "CCB3":"","CBACB5":"","CABACB6":"",
    // "CC2":"",
    // "CBC3":"","CABC4":"",
    // "CAA3":"","CBA3":"",
    // "CAAB4":"","CAAABAB7":"","CBAABAB7":"","CBBAB5":"","CACAB5":"","CBCAB5":"","CAABAB6":"","CBABAB6":"","CAABB5":"","CCAABBB7":"",
    // "CAAABB6":"","CBAABB6":"","CBABB5":"","CACABB6":"","CBCABB6":"","CBAABBB7":"","CCACB5":"",
    // "CAAABBB7":"","CABAABBB7":"","CBBAABBB8":"","CBABBB6":"","CABBBB6":"","CBBBBB6":"","CCBBB5":"",
    // "CAACB5":"","CAABACB7":"","CBABACB7":"","CBBACB6":"","CCBCB5":"" ,"CBCB4":"",
    // "CBAC4":"","CACAC5":"","CBCAC5":"","CCCAC5":"","CAAAC5":"","CBAAC5":"",
    // "CAABC5":"","CBABC5":"","CBBC4":"","CAC3":""
}
var End = {
    "AA3": { "href": "../mephas_web/1_1MFScondist/", "img": "image/portfolio/s1.PNG" },
    "BA3": { "href": "../mephas_web/1_2MFSdisdist/", "img": "image/portfolio/s2.PNG" },
    "AAB4": { "href": "../mephas_web/2MFSttest/", "img": "image/portfolio/s3.PNG" },
    "AABAB6": { "href": "../mephas_web/2MFSttest/", "img": "image/portfolio/s10.PNG" },
    "BABAB6": { "href": "../mephas_web/2MFSttest/", "img": "image/portfolio/s11.PNG" },
    "AABB5": { "href": "../mephas_web/4MFSproptest/", "img": "image/portfolio/s5.PNG" },
    "BABB5": { "href": "../mephas_web/4MFSproptest/", "img": "image/portfolio/s14.PNG" },
    "ACABB6": { "href": "../mephas_web/4MFSproptest/", "img": "image/portfolio/s15.PNG" },
    "BCABB6": { "href": "../mephas_web/4MFSproptest/", "img": "image/portfolio/s16.PNG" },
    "AAABBB7": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s6.PNG" },
    "BAABBB7": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s17.PNG" },
    "CAABBB7": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s18.PNG" },
    "BABBB6": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s21.PNG" },
    "ABBBB6": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s19.PNG" },
    "CBBB5": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s20.PNG" },
    "BBBBB6": { "href": "../mephas_web/5MFSrctabtest/", "img": "image/portfolio/s22.PNG" },
    "BBAB5": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s23.PNG" },
    "BBACB6": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s26.PNG" },
    "AACB5": { "href": "../mephas_web/3MFSnptest/", "img": "image/portfolio/s4.PNG" },
    "AABACB7": { "href": "../mephas_web/3MFSnptest/", "img": "image/portfolio/s12.PNG" },
    "BABACB7": { "href": "../mephas_web/3MFSnptest/", "img": "image/portfolio/s13.PNG" },
    "CACB5": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s25.PNG" },
    "ACAB5": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s7.PNG" },
    "BCAB5": { "href": "../mephas_web/6MFSanova/", "img": "image/portfolio/s24.PNG" },
    "AAAC5": { "href": "../mephas_web/7_1MFSlr/", "img": "image/portfolio/s27.PNG" },
    "BAAC5": { "href": "../mephas_web/7_2MFSlogit/", "img": "image/portfolio/s8.PNG" },
    "BCB4": { "href": "../mephas_web/7_3MFSsurv/", "img": "image/portfolio/s28.PNG" },
    "ACAAC6": { "href": "../mephas_web/7_3MFSsurv/", "img": "image/portfolio/s28.PNG" },
    "BCAAC6": { "href": "../mephas_web/7_3MFSsurv/", "img": "image/portfolio/s29.PNG" },
    "CCAAC6": { "href": "../mephas_web/7_3MFSsurv/", "img": "image/portfolio/s30.PNG" },
    "ABAC5": { "href": "../mephas_web/8_1MFSpca/", "img": "image/portfolio/s31.PNG" },
    "BBAC5": { "href": "../mephas_web/8_1MFSpca/", "img": "image/portfolio/s32.PNG" },
    "AABC5": { "href": "../mephas_web/8_2MFSpls/", "img": "image/portfolio/s33.PNG" },
    "BABC5": { "href": "../mephas_web/8_2MFSpls/", "img": "image/portfolio/s34.PNG" },
    "BBC4": { "href": "../mephas_web/8_2MFSpls/", "img": "image/portfolio/s35.PNG" }
    //"AAABAB7":{"href":"","img":""},"BAABAB7":{"href":"","img":""},"ACAB5":{"href":"","img":""},"BCAB5":{"href":"","img":""},
    //"AAABB6":{"href":"","img":""},"BAABB6":{"href":"","img":""},"BABB5":{"href":"","img":""},"ACABB6":{"href":"","img":""},"BCABB6":{"href":"","img":""},
    //"AAABBB7":{"href":"","img":""},"ABAABBB7":{"href":"","img":""},"BBAABBB8":{"href":"","img":""},"BABBB6":{"href":"","img":""},"ABBBB6":{"href":"","img":""},"CBBB5":{"href":"","img":""},
    //,"AABACB7":{"href":"","img":""},"BABACB7":{"href":"","img":""},"BBACB6":{"href":"","img":""},"CBCB5":{"href":"","img":""},"BCB4":{"href":"","img":""},
    //"AAC4":{"href":"","img":""},"BAC4":{"href":"","img":""},"ACAC5":{"href":"","img":""},"BCAC5":{"href":"","img":""},"CCAC5":{"href":"","img":""},
    //"AABC5":{"href":"","img":""},"BABC5":{"href":"","img":""},"BBC4":{"href":"","img":""}
}; //ゴール
var DirectryAhref = {
    /*"AAA3":"../mephas_web/1_1MFScondist/","AAAB4":"../mephas_web/2MFSttest/","AABAB5":"","AACAB5":"../mephas_web/6MFSanova/"*/
}
var DirectryBhref = {
    /* "BBA3":"../mephas_web/1_2MFSdisdist/","BAB3":"","BABAB5":"","BBAB4":"","ABCAB5":"../mephas_web/6MFSanova/"*/
}

function Reload() {
    qtext[1].innerHTML = Questiontext[Q];
    if (QustionsC['C' + Q] == "" || QustionsC['C' + Q] == null) {
        c.style.display = "none";
    } else {
        c.style.display = "block";
    }
    if (QustionsA['A' + Q] == "" || QustionsA['A' + Q] == null) {
        a.style.display = "none";
    } else {
        a.style.display = "block";
    }
    if (QustionsB['B' + Q] == "" || QustionsB['B' + Q] == null) {
        b.style.display = "none";
    } else {
        b.style.display = "block";
    }
    if (DirectryAhref['A' + Q]) { a.setAttribute("href", DirectryAhref['A' + Q]); } else { a.removeAttribute('href'); }
    if (DirectryBhref['B' + Q]) { b.setAttribute("href", DirectryBhref['B' + Q]); } else { b.removeAttribute('href'); }
    if (End[Q]) {
        a.style.display = "none";
        b.style.display = "none";
        c.style.display = "none";
        GoToEnd();
        return;
    } else {
        pic.style.display = "none";
    }
    a.innerHTML = QustionsA['A' + Q];
    b.innerHTML = QustionsB['B' + Q];
    c.innerHTML = QustionsC['C' + Q];
    // console.log(resetbu.getAttribute('href'));
}

function Restart() {
    num = 1;
    Q = num.toString();
    Reload();
}

function Back() {
    back();
    Reload();
}

function GoToEnd() {
    pic.style.display = "block";
    pic.setAttribute("href", End[Q]["href"]);
    src.setAttribute("src", End[Q]["img"]);
}

function next(mochi) {
    num++;
    Q = mochi + this.Q.substring(0, (this.Q.length) - 1) + num;
}

function back() {
    num--;
    Q = this.Q.substring(1, this.Q.length - 1) + num;
}

Reload();
// qtext[0].setAttribute("href","index_old.html");
// console.log(qtext[0].getAttribute('href'));
resetbu[0].onclick = function() {
    if (num == 1) { return }
    Back()
};
resetbu[1].onclick = function() {
    Restart()
};
$("#mochimochi").click(function() {
    next('A');
    Reload();
});
$("#mochinomochi").click(function() {
    next('B');
    Reload();
});
$("#momo").click(function() {
    next('C');
    Reload();
});